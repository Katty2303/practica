package cl.martinez.centro_medico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CentroMedicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
