package cl.martinez.centro_medico.crud.historial.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.martinez.centro_medico.crud.historial.dto.HistorialDTO;
import cl.martinez.centro_medico.crud.historial.service.impl.IHistorialService;

@RestController
@RequestMapping("/api/crud/historial")
public class HistorialController {
    @Autowired
    IHistorialService historialService;

    @PostMapping
    public HistorialDTO insert(@RequestBody HistorialDTO historial) {
        return historialService.insert(historial);
    }

    @PutMapping("/{id}")
    public HistorialDTO update(@PathVariable Integer id, @RequestBody HistorialDTO historial) {
        return historialService.update(id, historial);
    }

    @DeleteMapping("/{id}")
    public HistorialDTO delete(@PathVariable Integer id) {
        return historialService.delete(id);
    }

    @GetMapping("/{id}")
    public HistorialDTO getById(@PathVariable Integer id) {
        return historialService.getById(id);
    }

    @GetMapping
    public List<HistorialDTO> getAll() {
        return historialService.getAll();
    }

}
