package cl.martinez.centro_medico.crud.profesional.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.martinez.centro_medico.crud.profesional.dto.ProfesionalDTO;
import cl.martinez.centro_medico.crud.profesional.service.impl.IProfesionalService;

@RestController
@RequestMapping("/api/crud/profesional")
public class ProfesionalController {
    @Autowired
    IProfesionalService profesionalService;

    @PostMapping
    public ProfesionalDTO insert(@RequestBody ProfesionalDTO profesional) {
        return profesionalService.insert(profesional);
    }

    @PutMapping("/{id}")
    public ProfesionalDTO update(@PathVariable Integer id, @RequestBody ProfesionalDTO profesional) {
        return profesionalService.update(id, profesional);
    }

    @DeleteMapping("/{id}")
    public ProfesionalDTO delete(@PathVariable Integer id) {
        return profesionalService.delete(id);
    }

    @GetMapping("/{id}")
    public ProfesionalDTO getById(@PathVariable Integer id) {
        return profesionalService.getById(id);
    }

    @GetMapping
    public List<ProfesionalDTO> getAll() {
        return profesionalService.getAll();
    }

}
