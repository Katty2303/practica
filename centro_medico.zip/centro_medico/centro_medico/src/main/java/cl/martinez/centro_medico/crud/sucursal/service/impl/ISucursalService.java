package cl.martinez.centro_medico.crud.sucursal.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.sucursal.dto.SucursalDTO;

public interface ISucursalService {

    SucursalDTO insert(SucursalDTO sucursal);

    SucursalDTO update(Integer id, SucursalDTO sucursal);

    SucursalDTO delete(Integer id);

    SucursalDTO getById(Integer id);

    List<SucursalDTO> getAll();


}
