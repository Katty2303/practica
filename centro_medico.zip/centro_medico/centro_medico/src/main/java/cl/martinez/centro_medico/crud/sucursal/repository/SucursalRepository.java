package cl.martinez.centro_medico.crud.sucursal.repository;

import org.springframework.data.repository.CrudRepository;

import cl.martinez.centro_medico.crud.sucursal.dto.SucursalDTO;

public interface SucursalRepository extends CrudRepository<SucursalDTO, Integer> {

}
