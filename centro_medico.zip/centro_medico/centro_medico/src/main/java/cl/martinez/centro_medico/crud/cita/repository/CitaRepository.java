package cl.martinez.centro_medico.crud.cita.repository;

import org.springframework.data.repository.CrudRepository;

import cl.martinez.centro_medico.crud.cita.dto.CitaDTO;

public interface CitaRepository extends CrudRepository<CitaDTO, Integer> {

}
