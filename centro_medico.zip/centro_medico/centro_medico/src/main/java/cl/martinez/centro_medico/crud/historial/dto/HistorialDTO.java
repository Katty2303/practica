package cl.martinez.centro_medico.crud.historial.dto;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "historial_medico")
public class HistorialDTO {
    @Id
    @Column
    private int idHistorial;
    private Date fechaAtencion;
    private int idPaciente;
    private int idProfesional;
    private int idCita;
    private int idDiagnostico;
    private int idTratamiento;
}
