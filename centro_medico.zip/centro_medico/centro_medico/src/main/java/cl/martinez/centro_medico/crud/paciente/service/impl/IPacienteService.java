package cl.martinez.centro_medico.crud.paciente.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.paciente.dto.PacienteDTO;

public interface IPacienteService {

    PacienteDTO insert(PacienteDTO paciente);

    PacienteDTO update(Integer id, PacienteDTO paciente);

    PacienteDTO delete(Integer id);

    PacienteDTO getById(Integer id);

    List<PacienteDTO> getAll();

}
