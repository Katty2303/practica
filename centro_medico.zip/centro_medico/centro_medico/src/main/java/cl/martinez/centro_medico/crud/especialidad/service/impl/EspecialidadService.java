package cl.martinez.centro_medico.crud.especialidad.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.martinez.centro_medico.crud.especialidad.dto.EspecialidadDTO;
import cl.martinez.centro_medico.crud.especialidad.repository.EspecialidadRepository;
@Service
public class EspecialidadService implements IEspecialidadService {
    @Autowired
    EspecialidadRepository repositorio;

    @Override
    public EspecialidadDTO insert(EspecialidadDTO especialidad) {
        // TODO Auto-generated method stub
        return repositorio.save(especialidad);
    }

    @Override
    public EspecialidadDTO update(Integer id, EspecialidadDTO especialidad) {
        // TODO Auto-generated method stub
        especialidad.setIdEspecialidad(id);
        return repositorio.save(especialidad);
    }

    @Override
    public EspecialidadDTO delete(Integer id) {
        // TODO Auto-generated method stub
        repositorio.deleteById(id);
        return null;
    }

    @Override
    public EspecialidadDTO getById(Integer id) {
        // TODO Auto-generated method stub
        return repositorio.findById(id).get();
    }

    @Override
    public List<EspecialidadDTO> getAll() {
        // TODO Auto-generated method stub
        return (List<EspecialidadDTO>) repositorio.findAll();
    }

}
