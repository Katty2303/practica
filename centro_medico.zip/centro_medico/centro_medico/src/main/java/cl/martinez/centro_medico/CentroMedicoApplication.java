package cl.martinez.centro_medico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CentroMedicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CentroMedicoApplication.class, args);
	}

}
