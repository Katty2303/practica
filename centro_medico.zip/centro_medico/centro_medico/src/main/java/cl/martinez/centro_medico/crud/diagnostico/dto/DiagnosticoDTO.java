package cl.martinez.centro_medico.crud.diagnostico.dto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "diagnostico")
public class DiagnosticoDTO {
    @Id
    @Column
    private int idDiagnostico;
    private String nombre;
}
