package cl.martinez.centro_medico.crud.ficha_paciente.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.martinez.centro_medico.crud.ficha_paciente.dto.FichaPacienteDTO;
import cl.martinez.centro_medico.crud.ficha_paciente.repository.FichaPacienteRepository;

@Service
public class FichaPacienteService implements IFichaPacienteService {
    @Autowired
    FichaPacienteRepository repositorio;

    @Override
    public FichaPacienteDTO insert(FichaPacienteDTO ficha) {
        // TODO Auto-generated method stub
        return repositorio.save(ficha);
    }

    @Override
    public FichaPacienteDTO update(Integer id, FichaPacienteDTO ficha) {
        // TODO Auto-generated method stub
        ficha.setIdFicha(id);
        return repositorio.save(ficha);
    }

    @Override
    public FichaPacienteDTO delete(Integer id) {
        // TODO Auto-generated method stub
        repositorio.deleteById(id);
        return null;
    }

    @Override
    public FichaPacienteDTO getById(Integer id) {
        // TODO Auto-generated method stub
        return repositorio.findById(id).get();
    }

    @Override
    public List<FichaPacienteDTO> getAll() {
        // TODO Auto-generated method stub
        return (List<FichaPacienteDTO>) repositorio.findAll();
    }

}
