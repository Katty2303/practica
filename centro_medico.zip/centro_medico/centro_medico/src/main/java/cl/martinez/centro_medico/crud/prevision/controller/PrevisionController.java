package cl.martinez.centro_medico.crud.prevision.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.martinez.centro_medico.crud.prevision.dto.PrevisionDTO;
import cl.martinez.centro_medico.crud.prevision.service.impl.IPrevisionService;

@RestController
@RequestMapping("/api/crud/prevision")
public class PrevisionController {
    @Autowired
    IPrevisionService previsionService;

    @PostMapping
    public PrevisionDTO insert(@RequestBody PrevisionDTO prevision) {
        return previsionService.insert(prevision);
    }

    @PutMapping("/{id}")
    public PrevisionDTO update(@PathVariable Integer id, @RequestBody PrevisionDTO prevision) {
        return previsionService.update(id, prevision);
    }

    @DeleteMapping("/{id}")
    public PrevisionDTO delete(@PathVariable Integer id) {
        return previsionService.delete(id);
    }

    @GetMapping("/{id}")
    public PrevisionDTO getById(@PathVariable Integer id) {
        return previsionService.getById(id);
    }

    @GetMapping
    public List<PrevisionDTO> getAll() {
        return previsionService.getAll();
    }

}
