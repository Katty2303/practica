package cl.martinez.centro_medico.crud.tratamiento.repository;

import org.springframework.data.repository.CrudRepository;

import cl.martinez.centro_medico.crud.tratamiento.dto.TratamientoDTO;

public interface TratamientoRepository extends CrudRepository<TratamientoDTO, Integer>{

}
