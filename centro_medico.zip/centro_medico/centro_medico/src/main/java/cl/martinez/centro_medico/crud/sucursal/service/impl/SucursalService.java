package cl.martinez.centro_medico.crud.sucursal.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.martinez.centro_medico.crud.sucursal.dto.SucursalDTO;
import cl.martinez.centro_medico.crud.sucursal.repository.SucursalRepository;
@Service
public class SucursalService implements ISucursalService {
    @Autowired
    SucursalRepository repositorio;

    @Override
    public SucursalDTO insert(SucursalDTO sucursal) {
        // TODO Auto-generated method stub
        return repositorio.save(sucursal);
    }

    @Override
    public SucursalDTO update(Integer id, SucursalDTO sucursal) {
        // TODO Auto-generated method stub
        sucursal.setIdSucursal(id);
        return repositorio.save(sucursal);
    }

    @Override
    public SucursalDTO delete(Integer id) {
        // TODO Auto-generated method stub
        repositorio.deleteById(id);
        return null;
    }

    @Override
    public SucursalDTO getById(Integer id) {
        // TODO Auto-generated method stub
        return repositorio.findById(id).get();
    }

    @Override
    public List<SucursalDTO> getAll() {
        // TODO Auto-generated method stub
        return (List<SucursalDTO>) repositorio.findAll();
    }

}
