package cl.martinez.centro_medico.crud.prevision.repository;

import org.springframework.data.repository.CrudRepository;

import cl.martinez.centro_medico.crud.prevision.dto.PrevisionDTO;

public interface PrevisionRepository extends CrudRepository<PrevisionDTO, Integer> {

}
