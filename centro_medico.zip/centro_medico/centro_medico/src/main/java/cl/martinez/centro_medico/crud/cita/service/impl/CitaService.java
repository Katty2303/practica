package cl.martinez.centro_medico.crud.cita.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.martinez.centro_medico.crud.cita.dto.CitaDTO;
import cl.martinez.centro_medico.crud.cita.repository.CitaRepository;
@Service
public class CitaService implements ICitaService{
    @Autowired
    CitaRepository repositorio;

    @Override
    public CitaDTO insert(CitaDTO cita) {
        // TODO Auto-generated method stub
        return repositorio.save(cita);
    }

    @Override
    public CitaDTO update(Integer id, CitaDTO cita) {
        // TODO Auto-generated method stub
        cita.setIdCita(id);
        return repositorio.save(cita);
    }

    @Override
    public CitaDTO delete(Integer id) {
        // TODO Auto-generated method stub
        repositorio.deleteById(id);
        return null;
    }

    @Override
    public CitaDTO getById(Integer id) {
        // TODO Auto-generated method stub
        return repositorio.findById(id).get();
    }

    @Override
    public List<CitaDTO> getAll() {
        // TODO Auto-generated method stub
        return (List<CitaDTO>) repositorio.findAll();
    }

}
