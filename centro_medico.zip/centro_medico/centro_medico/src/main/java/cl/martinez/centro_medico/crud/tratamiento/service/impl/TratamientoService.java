package cl.martinez.centro_medico.crud.tratamiento.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.martinez.centro_medico.crud.tratamiento.dto.TratamientoDTO;
import cl.martinez.centro_medico.crud.tratamiento.repository.TratamientoRepository;
@Service
public class TratamientoService implements ITratamientoService{
    @Autowired
    TratamientoRepository repositorio;

    @Override
    public TratamientoDTO insert(TratamientoDTO tratamiento) {
        // TODO Auto-generated method stub
        return repositorio.save(tratamiento);
    }

    @Override
    public TratamientoDTO update(Integer id, TratamientoDTO tratamiento) {
        // TODO Auto-generated method stub
        tratamiento.setIdTratamiento(id);
        return repositorio.save(tratamiento);
    }

    @Override
    public TratamientoDTO delete(Integer id) {
        // TODO Auto-generated method stub
        repositorio.deleteById(id);
        return null;
    }

    @Override
    public TratamientoDTO getById(Integer id) {
        // TODO Auto-generated method stub
        return repositorio.findById(id).get();
    }

    @Override
    public List<TratamientoDTO> getAll() {
        // TODO Auto-generated method stub
        return (List<TratamientoDTO>) repositorio.findAll();
    }

}
