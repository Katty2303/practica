package cl.martinez.centro_medico.crud.horario.repository;

import org.springframework.data.repository.CrudRepository;

import cl.martinez.centro_medico.crud.horario.dto.HorarioDTO;

public interface HorarioRepository extends CrudRepository<HorarioDTO, Integer>{

}
