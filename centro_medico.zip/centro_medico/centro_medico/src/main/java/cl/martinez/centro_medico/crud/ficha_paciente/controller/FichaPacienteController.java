package cl.martinez.centro_medico.crud.ficha_paciente.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.martinez.centro_medico.crud.ficha_paciente.dto.FichaPacienteDTO;
import cl.martinez.centro_medico.crud.ficha_paciente.service.impl.IFichaPacienteService;

@RestController
@RequestMapping("/api/crud/ficha")
public class FichaPacienteController {
    @Autowired
    IFichaPacienteService fichaPacienteService;

    @PostMapping
    public FichaPacienteDTO insert(@RequestBody FichaPacienteDTO ficha) {
        return fichaPacienteService.insert(ficha);
    }

    @PutMapping("/{id}")
    public FichaPacienteDTO update(@PathVariable Integer id, @RequestBody FichaPacienteDTO ficha) {
        return fichaPacienteService.update(id, ficha);
    }

    @DeleteMapping("/{id}")
    public FichaPacienteDTO delete(@PathVariable Integer id) {
        return fichaPacienteService.delete(id);
    }

    @GetMapping("/{id}")
    public FichaPacienteDTO getById(@PathVariable Integer id) {
        return fichaPacienteService.getById(id);
    }

    @GetMapping
    public List<FichaPacienteDTO> getAll() {
        return fichaPacienteService.getAll();
    }

}
