package cl.martinez.centro_medico.crud.prevision.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.prevision.dto.PrevisionDTO;

public interface IPrevisionService {

    PrevisionDTO insert(PrevisionDTO prevision);

    PrevisionDTO update(Integer id, PrevisionDTO prevision);

    PrevisionDTO delete(Integer id);

    PrevisionDTO getById(Integer id);

    List<PrevisionDTO> getAll();

}
