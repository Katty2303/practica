package cl.martinez.centro_medico.crud.ficha_paciente.repository;

import org.springframework.data.repository.CrudRepository;

import cl.martinez.centro_medico.crud.ficha_paciente.dto.FichaPacienteDTO;

public interface FichaPacienteRepository extends CrudRepository<FichaPacienteDTO, Integer>{

}
