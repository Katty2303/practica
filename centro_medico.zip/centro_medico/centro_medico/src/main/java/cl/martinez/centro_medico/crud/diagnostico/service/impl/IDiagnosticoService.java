package cl.martinez.centro_medico.crud.diagnostico.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.diagnostico.dto.DiagnosticoDTO;

public interface IDiagnosticoService {

    DiagnosticoDTO insert(DiagnosticoDTO diagnostico);

    DiagnosticoDTO update(Integer id, DiagnosticoDTO diagnostico);

    DiagnosticoDTO delete(Integer id);

    DiagnosticoDTO getById(Integer id);

    List<DiagnosticoDTO> getAll();

}
