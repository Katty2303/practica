package cl.martinez.centro_medico.crud.zona.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.martinez.centro_medico.crud.zona.dto.ZonaDTO;
import cl.martinez.centro_medico.crud.zona.repository.ZonaRepository;
@Service
public class ZonaService implements IZonaService {
    @Autowired
    ZonaRepository repositorio;

    @Override
    public ZonaDTO insert(ZonaDTO area) {
        // TODO Auto-generated method stub
        return repositorio.save(area);
    }

    @Override
    public ZonaDTO update(Integer id, ZonaDTO area) {
        // TODO Auto-generated method stub
        area.setIdArea(id);
        return repositorio.save(area);
    }

    @Override
    public ZonaDTO delete(Integer id) {
        // TODO Auto-generated method stub
        repositorio.deleteById(id);
        return null;
    }

    @Override
    public ZonaDTO getById(Integer id) {
        // TODO Auto-generated method stub
        return repositorio.findById(id).get();
    }

    @Override
    public List<ZonaDTO> getAll() {
        // TODO Auto-generated method stub
        return (List<ZonaDTO>) repositorio.findAll();
    }

}
