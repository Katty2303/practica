package cl.martinez.centro_medico.crud.paciente.dto;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name ="paciente")
public class PacienteDTO {
    @Id
    @Column
    private int idPaciente;
    private int rut;
    private String nombre;
    private String apePaterno;
    private String apeMaterno;
    private Date fechaNacimiento;
    private String correo;
    private String direccion;
    private int idPrevision;
    private int idTelefono;
    private int idUsuario;
}
