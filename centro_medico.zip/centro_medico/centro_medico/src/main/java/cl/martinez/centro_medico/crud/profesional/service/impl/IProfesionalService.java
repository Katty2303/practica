package cl.martinez.centro_medico.crud.profesional.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.profesional.dto.ProfesionalDTO;

public interface IProfesionalService {

    ProfesionalDTO insert(ProfesionalDTO profesional);

    ProfesionalDTO update(Integer id, ProfesionalDTO profesional);

    ProfesionalDTO delete(Integer id);

    ProfesionalDTO getById(Integer id);

    List<ProfesionalDTO> getAll();

}
