package cl.martinez.centro_medico.crud.especialidad.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.especialidad.dto.EspecialidadDTO;

public interface IEspecialidadService {

    EspecialidadDTO insert(EspecialidadDTO especialidad);

    EspecialidadDTO update(Integer id, EspecialidadDTO especialidad);

    EspecialidadDTO delete(Integer id);

    EspecialidadDTO getById(Integer id);

    List<EspecialidadDTO> getAll();

}
