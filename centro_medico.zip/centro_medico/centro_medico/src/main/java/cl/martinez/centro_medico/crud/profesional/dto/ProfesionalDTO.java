package cl.martinez.centro_medico.crud.profesional.dto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "profesional")
public class ProfesionalDTO {
    @Id
    @Column
    private int idProfesional;
    private int rut;
    private String nombre;
    private String apePaterno;
    private String apeMaterno;
    private String correo;
    private int IdEspecialidad;
    private int IdSucursal;
    private int IdUsuario;
}
