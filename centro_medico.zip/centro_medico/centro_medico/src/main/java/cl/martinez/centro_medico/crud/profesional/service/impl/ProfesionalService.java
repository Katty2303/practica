package cl.martinez.centro_medico.crud.profesional.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.martinez.centro_medico.crud.profesional.dto.ProfesionalDTO;
import cl.martinez.centro_medico.crud.profesional.repository.ProfesionalRepository;
@Service
public class ProfesionalService implements IProfesionalService {
    @Autowired
    ProfesionalRepository repositorio;

    @Override
    public ProfesionalDTO insert(ProfesionalDTO profesional) {
        // TODO Auto-generated method stub
        return repositorio.save(profesional);
    }

    @Override
    public ProfesionalDTO update(Integer id, ProfesionalDTO profesional) {
        // TODO Auto-generated method stub
        profesional.setIdProfesional(id);
        return repositorio.save(profesional);
    }

    @Override
    public ProfesionalDTO delete(Integer id) {
        // TODO Auto-generated method stub
        repositorio.deleteById(id);
        return null;
    }

    @Override
    public ProfesionalDTO getById(Integer id) {
        // TODO Auto-generated method stub
        return repositorio.findById(id).get();
    }

    @Override
    public List<ProfesionalDTO> getAll() {
        // TODO Auto-generated method stub
        return (List<ProfesionalDTO>) repositorio.findAll();
    }

}
