package cl.martinez.centro_medico.crud.paciente.repository;

import org.springframework.data.repository.CrudRepository;

import cl.martinez.centro_medico.crud.paciente.dto.PacienteDTO;

public interface PacienteRepository extends CrudRepository<PacienteDTO, Integer> {

}
