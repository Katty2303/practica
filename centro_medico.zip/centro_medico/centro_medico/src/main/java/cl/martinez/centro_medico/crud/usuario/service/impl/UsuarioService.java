package cl.martinez.centro_medico.crud.usuario.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.martinez.centro_medico.crud.usuario.dto.UsuarioDTO;
import cl.martinez.centro_medico.crud.usuario.repository.UsuarioRepository;
@Service
public class UsuarioService implements IUsuarioService{
    @Autowired
    UsuarioRepository repositorio;

    @Override
    public UsuarioDTO insert(UsuarioDTO usuario) {
        // TODO Auto-generated method stub
        return repositorio.save(usuario);
    }

    @Override
    public UsuarioDTO update(Integer id, UsuarioDTO usuario) {
        // TODO Auto-generated method stub
        usuario.setIdUsuario(id);
        return repositorio.save(usuario);
    }

    @Override
    public UsuarioDTO delete(Integer id) {
        // TODO Auto-generated method stub
        repositorio.deleteById(id);
        return null;
    }

    @Override
    public UsuarioDTO getById(Integer id) {
        // TODO Auto-generated method stub
        return repositorio.findById(id).get();
    }

    @Override
    public List<UsuarioDTO> getAll() {
        // TODO Auto-generated method stub
        return (List<UsuarioDTO>) repositorio.findAll();
    }

}
