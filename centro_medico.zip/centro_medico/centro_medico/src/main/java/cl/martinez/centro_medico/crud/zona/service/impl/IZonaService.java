package cl.martinez.centro_medico.crud.zona.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.zona.dto.ZonaDTO;

public interface IZonaService {

    ZonaDTO insert(ZonaDTO area);

    ZonaDTO update(Integer id, ZonaDTO area);

    ZonaDTO delete(Integer id);

    ZonaDTO getById(Integer id);

    List<ZonaDTO> getAll();

}
