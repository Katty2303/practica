package cl.martinez.centro_medico.crud.diagnostico.repository;

import org.springframework.data.repository.CrudRepository;

import cl.martinez.centro_medico.crud.diagnostico.dto.DiagnosticoDTO;

public interface DiagnosticoRepository extends CrudRepository<DiagnosticoDTO, Integer> {

}
