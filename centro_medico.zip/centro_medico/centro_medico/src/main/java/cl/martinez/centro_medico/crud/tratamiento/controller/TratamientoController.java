package cl.martinez.centro_medico.crud.tratamiento.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.martinez.centro_medico.crud.tratamiento.dto.TratamientoDTO;
import cl.martinez.centro_medico.crud.tratamiento.service.impl.ITratamientoService;

@RestController
@RequestMapping("/api/crud/tratamiento")
public class TratamientoController {
    @Autowired
    ITratamientoService tratamientoService;

    @PostMapping
    public TratamientoDTO insert(@RequestBody TratamientoDTO tratamiento) {
        return tratamientoService.insert(tratamiento);
    }

    @PutMapping("/{id}")
    public TratamientoDTO update(@PathVariable Integer id, @RequestBody TratamientoDTO tratamiento) {
        return tratamientoService.update(id, tratamiento);
    }

    @DeleteMapping("/{id}")
    public TratamientoDTO delete(@PathVariable Integer id) {
        return tratamientoService.delete(id);
    }

    @GetMapping("/{id}")
    public TratamientoDTO getById(@PathVariable Integer id) {
        return tratamientoService.getById(id);
    }

    @GetMapping
    public List<TratamientoDTO> getAll() {
        return tratamientoService.getAll();
    }

}
