package cl.martinez.centro_medico.crud.telefono.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.martinez.centro_medico.crud.telefono.dto.TelefonoDTO;
import cl.martinez.centro_medico.crud.telefono.repository.TelefonoRepository;
@Service
public class TelefonoService implements ITelefonoService {
    @Autowired
    TelefonoRepository repositorio;

    @Override
    public TelefonoDTO insert(TelefonoDTO telefono) {
        // TODO Auto-generated method stub
        return repositorio.save(telefono);
    }

    @Override
    public TelefonoDTO update(Integer id, TelefonoDTO telefono) {
        // TODO Auto-generated method stub
        telefono.setIdTelefono(id);
        return repositorio.save(telefono);
    }

    @Override
    public TelefonoDTO delete(Integer id) {
        // TODO Auto-generated method stub
        repositorio.deleteById(id);
        return null;
    }

    @Override
    public TelefonoDTO getById(Integer id) {
        // TODO Auto-generated method stub
        return repositorio.findById(id).get();
    }

    @Override
    public List<TelefonoDTO> getAll() {
        // TODO Auto-generated method stub
        return (List<TelefonoDTO>) repositorio.findAll();
    }

}
