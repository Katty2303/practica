package cl.martinez.centro_medico.crud.estado.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.estado.dto.EstadoDTO;

public interface IEstadoService {

    EstadoDTO insert(EstadoDTO estado);

    EstadoDTO update(Integer id, EstadoDTO estado);

    EstadoDTO delete(Integer id);

    EstadoDTO getById(Integer id);

    List<EstadoDTO> getAll();

}
