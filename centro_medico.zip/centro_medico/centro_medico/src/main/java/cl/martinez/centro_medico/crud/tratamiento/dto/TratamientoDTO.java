package cl.martinez.centro_medico.crud.tratamiento.dto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tratamiento")
public class TratamientoDTO {
    @Id
    @Column
    private int idTratamiento;
    private String nombre;
}
