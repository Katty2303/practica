package cl.martinez.centro_medico.crud.tratamiento.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.tratamiento.dto.TratamientoDTO;

public interface ITratamientoService {

    TratamientoDTO insert(TratamientoDTO tratamiento);

    TratamientoDTO update(Integer id, TratamientoDTO tratamiento);

    TratamientoDTO delete(Integer id);

    TratamientoDTO getById(Integer id);

    List<TratamientoDTO> getAll();

}
