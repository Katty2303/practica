package cl.martinez.centro_medico.crud.historial.repository;

import org.springframework.data.repository.CrudRepository;

import cl.martinez.centro_medico.crud.historial.dto.HistorialDTO;

public interface HistorialRepository extends CrudRepository<HistorialDTO, Integer> {

}
