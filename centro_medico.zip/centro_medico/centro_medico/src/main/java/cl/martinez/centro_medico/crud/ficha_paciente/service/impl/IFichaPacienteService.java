package cl.martinez.centro_medico.crud.ficha_paciente.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.ficha_paciente.dto.FichaPacienteDTO;

public interface IFichaPacienteService {

    FichaPacienteDTO insert(FichaPacienteDTO ficha);

    FichaPacienteDTO update(Integer id, FichaPacienteDTO ficha);

    FichaPacienteDTO delete(Integer id);

    FichaPacienteDTO getById(Integer id);

    List<FichaPacienteDTO> getAll();

}
