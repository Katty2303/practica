package cl.martinez.centro_medico.crud.estado.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.martinez.centro_medico.crud.estado.dto.EstadoDTO;
import cl.martinez.centro_medico.crud.estado.repository.EstadoRepository;
@Service
public class EstadoService implements IEstadoService{
    @Autowired
    EstadoRepository repositorio;

    @Override
    public EstadoDTO insert(EstadoDTO estado) {
        // TODO Auto-generated method stub
        return repositorio.save(estado);
    }

    @Override
    public EstadoDTO update(Integer id, EstadoDTO estado) {
        // TODO Auto-generated method stub
        estado.setIdEstado(id);
        return repositorio.save(estado);
    }

    @Override
    public EstadoDTO delete(Integer id) {
        // TODO Auto-generated method stub
        repositorio.deleteById(id);
        return null;
    }

    @Override
    public EstadoDTO getById(Integer id) {
        // TODO Auto-generated method stub
        return repositorio.findById(id).get();
    }

    @Override
    public List<EstadoDTO> getAll() {
        // TODO Auto-generated method stub
        return (List<EstadoDTO>) repositorio.findAll();
    }

}
