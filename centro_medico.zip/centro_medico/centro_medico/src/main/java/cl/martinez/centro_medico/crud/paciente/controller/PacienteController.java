package cl.martinez.centro_medico.crud.paciente.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.martinez.centro_medico.crud.paciente.dto.PacienteDTO;
import cl.martinez.centro_medico.crud.paciente.service.impl.IPacienteService;

@RestController
@RequestMapping("/api/crud/paciente")
public class PacienteController {
    @Autowired
    IPacienteService pacienteService;

    @PostMapping
    public PacienteDTO insert(@RequestBody PacienteDTO paciente) {
        return pacienteService.insert(paciente);
    }

    @PutMapping("/{id}")
    public PacienteDTO update(@PathVariable Integer id, @RequestBody PacienteDTO paciente) {
        return pacienteService.update(id, paciente);
    }

    @DeleteMapping("/{id}")
    public PacienteDTO delete(@PathVariable Integer id) {
        return pacienteService.delete(id);
    }

    @GetMapping("/{id}")
    public PacienteDTO getById(@PathVariable Integer id) {
        return pacienteService.getById(id);
    }

    @GetMapping
    public List<PacienteDTO> getAll() {
        return pacienteService.getAll();
    }

}
