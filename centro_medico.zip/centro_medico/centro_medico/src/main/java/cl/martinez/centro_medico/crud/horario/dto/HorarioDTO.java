package cl.martinez.centro_medico.crud.horario.dto;

// import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "horario_profesional")
public class HorarioDTO {
    @Id
    @Column
    private int idHorario;
    private String horaInicio;
    private String horaFin;
    private String disponible;
    private int idProfesional;
    private int idDia;
}
