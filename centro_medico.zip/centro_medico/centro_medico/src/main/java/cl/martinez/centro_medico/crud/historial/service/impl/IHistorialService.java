package cl.martinez.centro_medico.crud.historial.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.historial.dto.HistorialDTO;

public interface IHistorialService {

    HistorialDTO insert(HistorialDTO historial);

    HistorialDTO update(Integer id, HistorialDTO historial);

    HistorialDTO delete(Integer id);

    HistorialDTO getById(Integer id);

    List<HistorialDTO> getAll();

}
