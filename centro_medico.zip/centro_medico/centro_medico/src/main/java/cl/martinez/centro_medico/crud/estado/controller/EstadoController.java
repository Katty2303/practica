package cl.martinez.centro_medico.crud.estado.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.martinez.centro_medico.crud.estado.dto.EstadoDTO;
import cl.martinez.centro_medico.crud.estado.service.impl.IEstadoService;

@RestController
@RequestMapping("/api/crud/estado")
public class EstadoController {
    @Autowired
    IEstadoService estadoService;

    @PostMapping
    public EstadoDTO insert(@RequestBody EstadoDTO estado) {
        return estadoService.insert(estado);
    }

    @PutMapping("/{id}")
    public EstadoDTO update(@PathVariable Integer id, @RequestBody EstadoDTO estado) {
        return estadoService.update(id, estado);
    }

    @DeleteMapping("/{id}")
    public EstadoDTO delete(@PathVariable Integer id) {
        return estadoService.delete(id);
    }

    @GetMapping("/{id}")
    public EstadoDTO getById(@PathVariable Integer id) {
        return estadoService.getById(id);
    }

    @GetMapping
    public List<EstadoDTO> getAll() {
        return estadoService.getAll();
    }

}
