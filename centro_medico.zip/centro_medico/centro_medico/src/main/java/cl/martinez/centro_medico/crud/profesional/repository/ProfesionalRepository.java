package cl.martinez.centro_medico.crud.profesional.repository;

import org.springframework.data.repository.CrudRepository;

import cl.martinez.centro_medico.crud.profesional.dto.ProfesionalDTO;

public interface ProfesionalRepository extends CrudRepository<ProfesionalDTO, Integer> {

}
