package cl.martinez.centro_medico.crud.zona.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.martinez.centro_medico.crud.zona.dto.ZonaDTO;
import cl.martinez.centro_medico.crud.zona.service.impl.IZonaService;

@RestController
@RequestMapping("/api/crud/area")
public class ZonaController {
    @Autowired
    IZonaService zonaService;

    @PostMapping
    public ZonaDTO insert(@RequestBody ZonaDTO area) {
        return zonaService.insert(area);
    }

    @PutMapping("/{id}")
    public ZonaDTO update(@PathVariable Integer id, @RequestBody ZonaDTO area) {
        return zonaService.update(id, area);
    }

    @DeleteMapping("/{id}")
    public ZonaDTO delete(@PathVariable Integer id) {
        return zonaService.delete(id);
    }

    @GetMapping("/{id}")
    public ZonaDTO getById(@PathVariable Integer id) {
        return zonaService.getById(id);
    }

    @GetMapping
    public List<ZonaDTO> getAll() {
        return zonaService.getAll();
    }

}
