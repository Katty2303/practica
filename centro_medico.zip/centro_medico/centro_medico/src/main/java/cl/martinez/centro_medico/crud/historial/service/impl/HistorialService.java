package cl.martinez.centro_medico.crud.historial.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.martinez.centro_medico.crud.historial.dto.HistorialDTO;
import cl.martinez.centro_medico.crud.historial.repository.HistorialRepository;
@Service
public class HistorialService implements IHistorialService{
    @Autowired
    HistorialRepository repositorio;

    @Override
    public HistorialDTO insert(HistorialDTO historial) {
        // TODO Auto-generated method stub
        return repositorio.save(historial);
    }

    @Override
    public HistorialDTO update(Integer id, HistorialDTO historial) {
        // TODO Auto-generated method stub
        historial.setIdHistorial(id);
        return repositorio.save(historial);
    }

    @Override
    public HistorialDTO delete(Integer id) {
        // TODO Auto-generated method stub
        repositorio.deleteById(id);
        return null;
    }

    @Override
    public HistorialDTO getById(Integer id) {
        // TODO Auto-generated method stub
        return repositorio.findById(id).get();
    }

    @Override
    public List<HistorialDTO> getAll() {
        // TODO Auto-generated method stub
        return (List<HistorialDTO>) repositorio.findAll();
    }

}
