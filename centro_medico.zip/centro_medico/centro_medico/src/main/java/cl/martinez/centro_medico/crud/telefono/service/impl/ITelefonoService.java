package cl.martinez.centro_medico.crud.telefono.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.telefono.dto.TelefonoDTO;

public interface ITelefonoService {

    TelefonoDTO insert(TelefonoDTO telefono);

    TelefonoDTO update(Integer id, TelefonoDTO telefono);

    TelefonoDTO delete(Integer id);

    TelefonoDTO getById(Integer id);

    List<TelefonoDTO> getAll();

}
