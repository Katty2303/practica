package cl.martinez.centro_medico.crud.diagnostico.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.martinez.centro_medico.crud.diagnostico.dto.DiagnosticoDTO;
import cl.martinez.centro_medico.crud.diagnostico.repository.DiagnosticoRepository;

@Service
public class DiagnosticoService implements IDiagnosticoService{
    @Autowired
    DiagnosticoRepository repositorio;

    @Override
    public DiagnosticoDTO insert(DiagnosticoDTO diagnostico) {
        // TODO Auto-generated method stub
        return repositorio.save(diagnostico);
    }

    @Override
    public DiagnosticoDTO update(Integer id, DiagnosticoDTO diagnostico) {
        // TODO Auto-generated method stub
        diagnostico.setIdDiagnostico(id);
        return repositorio.save(diagnostico);
    }

    @Override
    public DiagnosticoDTO delete(Integer id) {
        // TODO Auto-generated method stub
        repositorio.deleteById(id);
        return null;
    }

    @Override
    public DiagnosticoDTO getById(Integer id) {
        // TODO Auto-generated method stub
        return repositorio.findById(id).get();
    }

    @Override
    public List<DiagnosticoDTO> getAll() {
        // TODO Auto-generated method stub
        return (List<DiagnosticoDTO>) repositorio.findAll();
    }

}
