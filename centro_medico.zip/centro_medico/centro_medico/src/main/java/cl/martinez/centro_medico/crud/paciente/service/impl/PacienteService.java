package cl.martinez.centro_medico.crud.paciente.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.martinez.centro_medico.crud.paciente.dto.PacienteDTO;
import cl.martinez.centro_medico.crud.paciente.repository.PacienteRepository;

@Service
public class PacienteService implements IPacienteService {
    @Autowired
    PacienteRepository repositorio;

    @Override
    public PacienteDTO insert(PacienteDTO paciente) {
        // TODO Auto-generated method stub
        return repositorio.save(paciente);
    }

    @Override
    public PacienteDTO update(Integer id, PacienteDTO paciente) {
        // TODO Auto-generated method stub
        paciente.setIdPaciente(id);
        return repositorio.save(paciente);
    }

    @Override
    public PacienteDTO delete(Integer id) {
        // TODO Auto-generated method stub
        repositorio.deleteById(id);
        return null;
    }

    @Override
    public PacienteDTO getById(Integer id) {
        // TODO Auto-generated method stub
        return repositorio.findById(id).get();
    }

    @Override
    public List<PacienteDTO> getAll() {
        // TODO Auto-generated method stub
        return (List<PacienteDTO>) repositorio.findAll();
    }

}
