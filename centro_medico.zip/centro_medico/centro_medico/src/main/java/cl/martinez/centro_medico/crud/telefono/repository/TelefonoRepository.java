package cl.martinez.centro_medico.crud.telefono.repository;

import org.springframework.data.repository.CrudRepository;

import cl.martinez.centro_medico.crud.telefono.dto.TelefonoDTO;

public interface TelefonoRepository extends CrudRepository<TelefonoDTO, Integer>{

}
