package cl.martinez.centro_medico.crud.usuario.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.usuario.dto.UsuarioDTO;

public interface IUsuarioService {

    UsuarioDTO insert(UsuarioDTO usuario);

    UsuarioDTO update(Integer id, UsuarioDTO usuario);

    UsuarioDTO delete(Integer id);

    UsuarioDTO getById(Integer id);

    List<UsuarioDTO> getAll();

}
