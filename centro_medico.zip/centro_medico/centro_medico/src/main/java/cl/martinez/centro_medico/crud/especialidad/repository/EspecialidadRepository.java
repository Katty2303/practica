package cl.martinez.centro_medico.crud.especialidad.repository;

import org.springframework.data.repository.CrudRepository;

import cl.martinez.centro_medico.crud.especialidad.dto.EspecialidadDTO;

public interface EspecialidadRepository extends CrudRepository<EspecialidadDTO, Integer> {

}
