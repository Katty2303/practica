package cl.martinez.centro_medico.crud.cita.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.martinez.centro_medico.crud.cita.dto.CitaDTO;
import cl.martinez.centro_medico.crud.cita.service.impl.ICitaService;

@RestController
@RequestMapping("/api/crud/cita")
public class CitaController {
    @Autowired
    ICitaService citaService;

    @PostMapping
    public CitaDTO insert(@RequestBody CitaDTO cita) {
        return citaService.insert(cita);
    }

    @PutMapping("/{id}")
    public CitaDTO update(@PathVariable Integer id, @RequestBody CitaDTO cita) {
        return citaService.update(id, cita);
    }

    @DeleteMapping("/{id}")
    public CitaDTO delete(@PathVariable Integer id) {
        return citaService.delete(id);
    }

    @GetMapping("/{id}")
    public CitaDTO getById(@PathVariable Integer id) {
        return citaService.getById(id);
    }

    @GetMapping
    public List<CitaDTO> getAll() {
        return citaService.getAll();
    }

}
