package cl.martinez.centro_medico.crud.especialidad.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.martinez.centro_medico.crud.especialidad.dto.EspecialidadDTO;
import cl.martinez.centro_medico.crud.especialidad.service.impl.IEspecialidadService;

@RestController
@RequestMapping("/api/crud/especialidad")
public class EspecialidadController {
    @Autowired
    IEspecialidadService especialidadService;
    @PostMapping
    public EspecialidadDTO insert(@RequestBody EspecialidadDTO especialidad) {
        return especialidadService.insert(especialidad);
    }

    @PutMapping("/{id}")
    public EspecialidadDTO update(@PathVariable Integer id, @RequestBody EspecialidadDTO especialidad) {
        return especialidadService.update(id, especialidad);
    }

    @DeleteMapping("/{id}")
    public EspecialidadDTO delete(@PathVariable Integer id) {
        return especialidadService.delete(id);
    }

    @GetMapping("/{id}")
    public EspecialidadDTO getById(@PathVariable Integer id) {
        return especialidadService.getById(id);
    }

    @GetMapping
    public List<EspecialidadDTO> getAll() {
        return especialidadService.getAll();
    }

}
