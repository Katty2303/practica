package cl.martinez.centro_medico.crud.sucursal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.martinez.centro_medico.crud.sucursal.dto.SucursalDTO;
import cl.martinez.centro_medico.crud.sucursal.service.impl.ISucursalService;

@RestController
@RequestMapping("/api/crud/sucursal")
public class SucursalController {
    @Autowired
    ISucursalService sucursalService;

    @PostMapping
    public SucursalDTO insert(@RequestBody SucursalDTO sucursal) {
        return sucursalService.insert(sucursal);
    }

    @PutMapping("/{id}")
    public SucursalDTO update(@PathVariable Integer id, @RequestBody SucursalDTO sucursal) {
        return sucursalService.update(id, sucursal);
    }

    @DeleteMapping("/{id}")
    public SucursalDTO delete(@PathVariable Integer id) {
        return sucursalService.delete(id);
    }

    @GetMapping("/{id}")
    public SucursalDTO getById(@PathVariable Integer id) {
        return sucursalService.getById(id);
    }

    @GetMapping
    public List<SucursalDTO> getAll() {
        return sucursalService.getAll();
    }

}
