package cl.martinez.centro_medico.crud.dia.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.dia.dto.DiaDTO;

public interface IDiaService {

    DiaDTO insert(DiaDTO dia);

    DiaDTO update(Integer id, DiaDTO dia);

    DiaDTO delete(Integer id);

    DiaDTO getById(Integer id);

    List<DiaDTO> getAll();

}
