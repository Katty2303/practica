package cl.martinez.centro_medico.crud.cita.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.cita.dto.CitaDTO;

public interface ICitaService {

    CitaDTO insert(CitaDTO cita);

    CitaDTO update(Integer id, CitaDTO cita);

    CitaDTO delete(Integer id);

    CitaDTO getById(Integer id);

    List<CitaDTO> getAll();

}
