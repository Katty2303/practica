package cl.martinez.centro_medico.crud.horario.service.impl;

import java.util.List;

import cl.martinez.centro_medico.crud.horario.dto.HorarioDTO;

public interface IHorarioService {

    HorarioDTO insert(HorarioDTO horario);

    HorarioDTO update(Integer id, HorarioDTO horario);

    HorarioDTO delete(Integer id);

    HorarioDTO getById(Integer id);

    List<HorarioDTO> getAll();

}
